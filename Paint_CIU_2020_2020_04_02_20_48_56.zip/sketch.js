function setup() {
  createCanvas(800, 600);

  grosor = [];
  trazo = [];
  valGrosor = 1;
  numSubTrazos = 0;
  numTrazo = 0;
  indexColorP = 0;
  indexColorBG = 8;
  numPuntosNuevos = 0;
  modoPincel = true;
  
  colores = [
    color(255, 255, 255),
    color(255, 255, 0),
    color(255, 0, 255),
    color(255, 0, 0),
    color(0, 255, 255),
    color(0, 255, 0),
    color(0, 0, 255),
    color(0, 0, 0),
    color(128, 128, 128),
    color(128, 128, 32),
    color(128, 32, 128),
    color(128, 32, 32),
    color(32, 128, 128),
    color(32, 128, 32),
    color(32, 32, 128),
    color(32, 32, 32)
  ];
}

function dibujaLienzo() {

  fill(colores[indexColorBG]);
  rect(0, 95, 800, 705);

  let pNumTrazo = 0;
  for (let i = 0; i < numSubTrazos - 1; i++) {
    stroke(colores[trazo[i][3]]);
    strokeWeight(trazo[i][2]);
    if (pNumTrazo != trazo[i+1][4]) {
      pNumTrazo = trazo[i+1][4];
    } else {
      line(trazo[i][0], trazo[i][1], trazo[i + 1][0], trazo[i+1][1]);
    }
  }

  strokeWeight(1);
  stroke(0);
}

function dibujaMenuColor() {
  fill(200);
  rect(0, 0, 400, 95);

  fill(0);
  textAlign(LEFT, TOP);
  if (modoPincel) {
    text("Color del pincel: ", 10, 15);
  } else {
    text("Color de fondo: ", 10, 15);
  }

  fill(255);
  rect(32, 45, 40, 40);

  if (modoPincel) {
    fill(colores[indexColorP]);
  } else {
    fill(colores[indexColorBG]);
  }

  rect(37, 50, 30, 30);

  fill(255);
  rect(105, 10, 285, 75);

  for (let i = 0; i < 8; i++) {
    fill(colores[i]);
    rect(110 + 35 * i, 15, 30, 30);
    fill(colores[i+8]);
    rect(110 + 35 * i, 50, 30, 30);
  }

}

function dibujaMenuGrosorPincel() {
  fill(200);
  rect(400, 0, 400, 95);

  fill(0);
  textAlign(LEFT, TOP);
  text("Grosor del pincel: ", 410, 15);

  fill(255);
  rect(410, 40, 380, 45);

  line(420, 55, 780, 55);

  textAlign(CENTER, TOP);
  fill(0);
  for (let i = 0; i < 10; i++) {
    line(420 + 40 * i, 55, 420 + 40 * i, 60);
    text(str(i + 1), 420 + 40 * i, 65);
    append(grosor, 420 + 40 * i);
  }

  fill(colores[indexColorP]);
  circle(grosor[valGrosor-1], 55, 10);

}

function dibujaAyuda() {
  fill(200);
  rect(570, 95, 230, 60);

  fill(0);
  textAlign(LEFT, TOP);
  text("Para limpiar el lienzo pulse l", 575, 100);

  if (modoPincel) {
    text("Para cambiar el color de fondo pulse c", 575, 120);
  } else {
    text("Para cambiar el color del pincel pulse c", 575, 120);
  }

  text("Para eliminar el último trazo pulse d", 575, 140);
}

function draw() {
  clear();

  textSize(12);
  textStyle(NORMAL);

  dibujaLienzo();
  dibujaMenuColor();
  dibujaMenuGrosorPincel();

  dibujaAyuda();
}

function borraTrazo() {
  if (numSubTrazos > 0) {
    let i = numSubTrazos - 1;
    let aux_numTrazo = trazo[i][4];
    while (i > 0 && trazo[i][4] == aux_numTrazo) {
      i--;
    }

    if (i == 0) {
      trazo = [];
      numSubTrazos = 0;
      numTrazo = 0;
    } else {
      trazo = subset(trazo, 0, i + 1);
      numSubTrazos = i + 1;
      numTrazo -= 1;
    }
  }
}

function mouseClicked() {
  if (mouseX > 110 && mouseX < 385 && mouseY > 15 && mouseY < 80) {
    let posX = int((mouseX - 110) / 34.375);
    let posY = int((mouseY - 15) / 32.5);
    if (modoPincel) {
      indexColorP = posY * 8 + posX;
    } else {
      indexColorBG = posY * 8 + posX;
    }
  }

  if (mouseX > 415 && mouseX < 785 && mouseY > 40 && mouseY < 80) {
    valGrosor = round(9 * (mouseX - 415) / (785 - 415)) + 1;
  }
}

function mouseDragged() {

  if (mouseY > 95) {
    let distancia = abs(winMouseX - pwinMouseX);

    if (distancia > 1) {
      append(trazo, [mouseX, mouseY, valGrosor * 2, indexColorP, numTrazo]);
      numSubTrazos++;
      numPuntosNuevos++;
    }
  }
}

function mouseReleased() {
  if (numPuntosNuevos > 0) {
    numTrazo++;
    numPuntosNuevos = 0;
  }
}

function keyPressed() {
  if (key == 'l') {
    trazo = [];
    numTrazo = 0;
    numSubTrazos = 0;
    numPuntosNuevos = 0;
  }

  if (key == 'c') {
    if (modoPincel) {
      modoPincel = false;
    } else {
      modoPincel = true;
    }
  }

  if (key == 'd') {
    borraTrazo();
  }
}